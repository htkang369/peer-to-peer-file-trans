package com.whz;

public class BitField {
	public byte[] bitfield;
}
